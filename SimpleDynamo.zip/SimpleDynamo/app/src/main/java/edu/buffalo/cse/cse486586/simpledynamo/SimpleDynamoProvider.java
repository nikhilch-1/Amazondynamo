package edu.buffalo.cse.cse486586.simpledynamo;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Formatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;
import android.util.Log;
import java.util.PriorityQueue;
import java.util.concurrent.locks.ReentrantLock;

public class SimpleDynamoProvider extends ContentProvider {

    final String TAG = SimpleDynamoActivity.class.getSimpleName();
    static final String REMOTE_PORT0 = "11108";
    static final String REMOTE_PORT1 = "11112";
    static final String REMOTE_PORT2 = "11116";
    static final String REMOTE_PORT3 = "11120";
    static final String REMOTE_PORT4 = "11124";
    String[] remotePorts = new String[]{REMOTE_PORT0, REMOTE_PORT1, REMOTE_PORT2, REMOTE_PORT3, REMOTE_PORT4};
    static final int SERVER_PORT = 10000;
    String mPort = "";
    String sucPort = "";
    String sucPort2 = "";
    String predPort1 = "";
    String predPort2 = "";
    List<String> liveNodes = new ArrayList<String>();

    // The node class will have a value field and its time stamp.
    class Node implements Comparable<Node> {
        public String value;
        public long lastModified;

        public Node(String v, long time) {
            this.value = v;
            this.lastModified = time;
        }

        @Override
        public int compareTo(Node another) {

            if (this.lastModified < another.lastModified)
                return 1;
            return -1;
        }
    }

    //Map for <genHash(key),key>
    public Map<String, String> keyMap = new HashMap<String, String>();
    //Map for <genHash(key),data>
    public Map<String, String> dataMap = new HashMap<String, String>();
    // Map for resynchronizing predecessor 1
    public Map<String, String> pred1Map = new HashMap<String, String>();
    // Map for resynchronizing predecessor 2
    public Map<String, String> pred2Map = new HashMap<String, String>();
    // Private map
    public Map<String, String> privateMap = new HashMap<String, String>();
    // Maps for timestamps
    public Map<String, String> dataMapTime = new HashMap<String, String>();


    @Override
    public String getType(Uri uri) {
        // TODO Auto-generated method stub
        return null;
    }

    //=================================================================================================================================================
    //=================================================================================================================================================

    @Override
    public boolean onCreate() {
        // TODO Auto-generated method stub
        TelephonyManager tel = (TelephonyManager) getContext().getSystemService(Context.TELEPHONY_SERVICE);
        String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
        final String myPort = String.valueOf((Integer.parseInt(portStr) * 2));

        mPort = myPort;
        try {
            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
            new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);
        } catch (IOException e) {
            Log.e(TAG, "Can't create a ServerSocket");
        }
        return false;
    }

    //========================================================================================================================================================================
    //========================================================================================================================================================================
    private class ServerTask extends AsyncTask<ServerSocket, String, Void> {
        @Override
        protected Void doInBackground(ServerSocket... sockets) {
            // Recover the data first.
            getData();
            ServerSocket serverSocket = sockets[0];
            String line = "";
            try {
                while (true) {
                    // At any time, I will process only one thread.
                    synchronized (this) {
                        try {
                            Socket socket = serverSocket.accept();
                            DataInputStream in = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
                            line = in.readUTF();
                            String[] data = line.split(":");
                            if (line.startsWith("Resync")) {
                                String result = "";
                                DataOutputStream sendingBack = new DataOutputStream(socket.getOutputStream());

                                // If predecessor 1 is requesting recovery, I will send its key-value pairs stored in pred1Map.
                                if (data[1].equals("1")) {
                                    for (String each : pred1Map.keySet()) {
                                        result += each + "=" + pred1Map.get(each) + ";";
                                    }
                                }
                                // If predecessor 2 is requesting recovery, I will send its key-value pairs stored in pred2Map.
                                else if (data[1].equals("2")) {
                                    for (String each : pred2Map.keySet()) {
                                        result += each + "=" + pred2Map.get(each) + ";";
                                    }
                                }
                                sendingBack.writeUTF(result);
                                sendingBack.flush();
                            }
                            // If any of my 2 successors are requesting recovery, I will send the key-value pairs ( not replicated ones )
                            // on my node. These records are stored in privateMap.
                            else if (line.startsWith("Private")) {
                                String result = "";
                                DataOutputStream sendingBack = new DataOutputStream(socket.getOutputStream());
                                for (String key : privateMap.keySet()) {
                                    result += key + "=" + privateMap.get(key) + ";";
                                }
                                sendingBack.writeUTF(result);
                                sendingBack.flush();
                            }
                            // If it is an insert request, I will store it in my main map first, alongwith its timestamp.
                            else if (line.startsWith("Insert")) {
                                keyMap.put(genHash(data[1]), data[1]);
                                dataMap.put(genHash(data[1]), data[2]);
                                String time = String.valueOf(System.currentTimeMillis());
                                dataMapTime.put(data[2], time);
                                // If the key-value pair is originally meant to be stored in my node, I will store it in a private map as well.
                                if (data[3].equals("0"))
                                    privateMap.put(data[1], data[2]);
                                // If the key-value pair to be store is a replication of my 1st predecessor, I will store it in a separate map ( pred1Map ) as well.
                                else if (data[3].equals("1"))
                                    pred1Map.put(data[1], data[2]);
                                // If the key-value pair to be store is a replication of my 2nd predecessor, I will store it in a separate map ( pred2Map ) as well.
                                else if (data[3].equals("2"))
                                    pred2Map.put(data[1], data[2]);
                            }
                            // If it is a query request, I will send back the data from my main map ( keyMap and dataMap ) only.
                            else if (line.startsWith("Requesting")) {
                                wait(200);
                                String result = "";
                                DataOutputStream sendingBack = new DataOutputStream(socket.getOutputStream());
                                if (data[1].equals("*")) {
                                    for (String each : dataMap.keySet()) {
                                        result += keyMap.get(each) + "=" + dataMap.get(each) + ";";
                                    }
                                } else if (keyMap.containsKey(genHash(data[1]))) {
                                    result = keyMap.get(genHash(data[1])) + ":" + dataMap.get(genHash(data[1])) + ":" + dataMapTime.get(dataMap.get(genHash(data[1])));

                                }
                                sendingBack.writeUTF(result);
                                sendingBack.flush();
                            } else if (line.startsWith("Delete")) {
                                if (data[1].equals("*")) {
                                    keyMap.clear();
                                    dataMap.clear();
                                    pred1Map.clear();
                                    pred2Map.clear();
                                    privateMap.clear();
                                    Log.i("S", "Got * for delete. Cleared all my records");
                                } else {
                                    keyMap.remove(genHash(data[1]));
                                    dataMap.remove(genHash(data[1]));
                                    pred1Map.remove(data[1]);
                                    pred2Map.remove(data[1]);
                                    privateMap.remove(data[1]);
                                }

                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onProgressUpdate(String... strings) {
            Log.e(TAG, "Published a message");
            return;
        }

    }

    //================================================================================================================================================
    //================================================================================================================================================

    //=================================================================================================================================================
    //=================================================================================================================================================

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        // TODO Auto-generated method stub
        String keyToStore = values.getAsString("key");
        String dataToStore = values.getAsString("value");
        ReentrantLock l = new ReentrantLock(true);
        // I will process only one insert request at a time, so I'm applying a local lock.
        try {
            // I will get the possible locations where the key-value pair is to be stored.
            List<String> ports = getDataCenters(genHash(keyToStore));
            l.lock();
            // I will send a direct message to these nodes to insert the given key-value pair in their main map.
            // In order to distinguish whether it is a replicated data or not ( for recovery part ), I will send a number
            // alongside the message.
            for (int i = 0; i < ports.size(); i++) {
                String eachPort = ports.get(i);
                Socket sock = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(eachPort));
                DataOutputStream sending = new DataOutputStream(sock.getOutputStream());
                sending.writeUTF("Insert:" + keyToStore + ":" + dataToStore + ":" + i);
                // If the number is 0: It is original data.
                // If the number is 1: It is a replication in its 1st successor.
                // If the number is 2: It is a replication in its 2nd successor.
                sending.flush();
                try {
                    Thread.sleep(50);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        } catch (NoSuchAlgorithmException e) {
            Log.e("Insert error:", "Failed to create my Hash");
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            l.unlock();
        }

        return null;
    }

    //========================================================================================================================================================================
    //========================================================================================================================================================================
    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs,
                        String sortOrder) {
        // TODO Auto-generated method stub


        MatrixCursor myCursor = new MatrixCursor(new String[]{"key", "value"});
        ReentrantLock l = new ReentrantLock(true);

        try {
            // While processing one query request, other query requests to this node should wait. So, I'm applying a local lock.
            l.lock();
            // If the query is "@", I will return all my records alongwith the replications of my two predecessors.
            if (selection.equals("@")) {
                for (String key : dataMap.keySet()) {
                    myCursor.addRow(new String[]{keyMap.get(key), dataMap.get(key)});
                }
            }
            // Else, I will get the possible locations of the data and send request to those nodes.
            else {
                List<String> ports = getDataCenters(genHash(selection));
                // If the query is "*", I will send a request to all the nodes to retreive all the records.
                if (selection.equals("*")) {
                    ports = Arrays.asList(remotePorts);
                }
                String result = "";
                // If multiple values are inserted for the same key, I need to return the most recent value. So, I will create a priority queue which will
                // be sorted according to timestamps. For comparing the timestamps, I've written a comparator in the Node class.
                PriorityQueue<Node> gettingLatestValue = new PriorityQueue<Node>();
                for (String eachPort : ports) {
                    Socket currentSoc = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(eachPort));
                    DataOutputStream getFromCurr = new DataOutputStream(currentSoc.getOutputStream());
                    getFromCurr.writeUTF("Requesting:" + selection);
                    getFromCurr.flush();
                    try {
                        DataInputStream reading = new DataInputStream(currentSoc.getInputStream());
                        result = reading.readUTF();
                        if (selection.equals("*")) {
                            String[] resultSplit = result.split(";");
                            for (String record : resultSplit) {
                                String[] rec = record.split("=");
                                myCursor.addRow(new String[]{rec[0], rec[1]});
                            }
                        }
                        else {
                            if (!result.isEmpty()) {
                                String[] resultSplit = result.split(":");
                                gettingLatestValue.add(new Node(resultSplit[1], Long.parseLong(resultSplit[2])));
                            }
                            currentSoc.close();

                        }
                    }
                    catch (Exception e) {
                        Log.e("Error", "Node might be down");
                    }
                }
                if (!gettingLatestValue.isEmpty()) {
                    // Since the priority queue has a custom comparator which would return objects in the decreasing order of their timestamp,
                    // Polling an element from this queue will always give the latest value for a given key.
                    Node temp = gettingLatestValue.poll();
                    myCursor.addRow(new String[]{selection, temp.value});
                }
                gettingLatestValue.clear();
            }
        } catch (NoSuchAlgorithmException e) {
            Log.e("QUERY:", "FAILED");
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            // After processing the request, I will allow other query requests one by one.
            l.unlock();
        }

        return myCursor;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        // TODO Auto-generated method stub


        return 0;
    }

    //=====================================================================================================================================================================
    //=====================================================================================================================================================================
    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        // TODO Auto-generated method stub
        try {
            // If the selection is "@", I will clear my Local DHT.
            if (selection.equals("@")) {
                keyMap.clear();
                dataMap.clear();
                pred1Map.clear();
                pred2Map.clear();
                privateMap.clear();
                dataMapTime.clear();
            }
            // Else if selection = *, I will delete my local DHT and forward the delete request to other nodes in the ring.
            else if (selection.equals("*")) {
                Log.i("DELELTE:", "* selected.. Deleting my local DHT first..");
                keyMap.clear();
                dataMap.clear();
                pred1Map.clear();
                pred2Map.clear();
                privateMap.clear();
                dataMapTime.clear();
                for (String port : remotePorts) {
                    Socket s = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(port));
                    DataOutputStream sendingDeleteReq = new DataOutputStream(s.getOutputStream());
                    sendingDeleteReq.writeUTF("Delete:" + selection);
                    Log.e("D", "Req Sent for " + selection);
                    sendingDeleteReq.flush();
                }
                Log.i("DELETE", "Local DHT cleared.");
                Log.i("DELETE", "Forwarded request to other nodes to clear their local DHT");
            } 
            // Else, I will get the locations of data and send request to those nodes for deleting them.
            else {
                String keyToDelete = genHash(selection);
                List<String> ports = getDataCenters(keyToDelete);
                for (String port : ports) {
                    Socket s = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(port));
                    DataOutputStream sendingDeleteReq = new DataOutputStream(s.getOutputStream());
                    sendingDeleteReq.writeUTF("Delete:" + selection);
                    sendingDeleteReq.flush();
                }
            }

        } catch (NoSuchAlgorithmException e) {
            Log.e("Delete:", "Hashing Error");
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        return 0;
    }

    //=====================================================================================================================================================================
    //=====================================================================================================================================================================


    //======================================================================================================================================================================
    //======================================================================================================================================================================
    public String getMyPort() {
        return mPort;
    }
    //======================================================================================================================================================================
    //======================================================================================================================================================================

    // This function is to get the possible locations for a given hash to be inserted, queried or deleted.
    public List<String> getDataCenters(String queryHash) {
        Map<String, String> forLinks = new HashMap<String, String>();
        List<String> result = new ArrayList<String>();
        List<String> nodes = new ArrayList<String>();
        nodes.add(REMOTE_PORT0);
        nodes.add(REMOTE_PORT1);
        nodes.add(REMOTE_PORT2);
        nodes.add(REMOTE_PORT3);
        nodes.add(REMOTE_PORT4);
        liveNodes = new ArrayList<String>(nodes);
        List<String> hashes = new ArrayList();
        for (int i = 0; i < nodes.size(); i++) {
            try {
                hashes.add(genHash(String.valueOf(Integer.parseInt(nodes.get(i)) / 2)));
                forLinks.put(genHash(String.valueOf(Integer.parseInt(nodes.get(i)) / 2)), nodes.get(i));
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }
        }
        hashes.add(queryHash);
        Collections.sort(hashes);
        int queryIndex = hashes.indexOf(queryHash);
        int currentIndex = (queryIndex + 1) % hashes.size();
        int sOneIndex = (queryIndex + 2) % hashes.size();
        int sTwoIndex = (queryIndex + 3) % hashes.size();
        result.add(forLinks.get(hashes.get(currentIndex)));
        result.add(forLinks.get(hashes.get(sOneIndex)));
        result.add(forLinks.get(hashes.get(sTwoIndex)));
        return result;
    }


    //===========================================================================================================================================================
    //===========================================================================================================================================================

    // This is the recovery function. It is executed everytime a node starts the application.
    // It will get the 2 successors and 2 predecessors and request data from them.
    public void getData() {

        String result = "";
        String[] nodes = new String[]{REMOTE_PORT0, REMOTE_PORT1, REMOTE_PORT2, REMOTE_PORT3, REMOTE_PORT4};
        Map<String, String> forLinks = new HashMap<String, String>();
        String successor1 = "";
        String successor2 = "";
        String pred1 = "";
        String pred2 = "";
        List<String> sucPorts = new ArrayList<String>();
        List<String> predPorts = new ArrayList<String>();
        List<String> hashes = new ArrayList();
        List<String> ring = new ArrayList<String>();
        for (int i = 0; i < nodes.length; i++) {
            try {
                hashes.add(genHash(String.valueOf(Integer.parseInt(nodes[i]) / 2)));
                forLinks.put(genHash(String.valueOf(Integer.parseInt(nodes[i]) / 2)), nodes[i]);
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }
        }
        Collections.sort(hashes);
        for (String hash : hashes) {
            ring.add(forLinks.get(hash));
        }
        Log.i("Ring", "-->" + ring);
        try {
            String myHash = genHash(Integer.toString(Integer.parseInt(getMyPort()) / 2));

            for (int i = 0; i < hashes.size(); i++) {
                if (hashes.get(i).equals(myHash)) {
                    if (i == 0) {
                        pred1 = hashes.get(hashes.size() - 1);
                        pred2 = hashes.get(hashes.size() - 2);
                        successor1 = hashes.get(i + 1);
                        successor2 = hashes.get(i + 2);
                    } else if (i == hashes.size() - 1) {
                        pred1 = hashes.get(i - 1);
                        pred2 = hashes.get(i - 2);
                        successor1 = hashes.get(0);
                        successor2 = hashes.get(1);
                    } else {
                        if (i - 1 < 0) {
                            int j = (i - 1 + hashes.size()) % hashes.size();
                            pred1 = hashes.get(j);
                        } else {
                            pred1 = hashes.get(i - 1);
                        }
                        if (i - 2 < 0) {
                            int j = (i - 2 + hashes.size()) % hashes.size();
                            pred2 = hashes.get(j);
                        } else {
                            pred2 = hashes.get(i - 2);
                        }
                        successor1 = hashes.get(i + 1);
                        successor2 = hashes.get((i + 2) % hashes.size());
                    }
                }
            }
            sucPort = forLinks.get(successor1);
            sucPort2 = forLinks.get(successor2);
            predPort1 = forLinks.get(pred1);
            predPort2 = forLinks.get(pred2);
            predPorts.add(predPort1);
            predPorts.add(predPort2);
            sucPorts.add(forLinks.get(successor1));
            sucPorts.add(forLinks.get(successor2));

            for (int i = 0; i < sucPorts.size(); i++) {
                Socket s = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(sucPorts.get(i)));
                DataOutputStream requestReSync = new DataOutputStream(s.getOutputStream());
                requestReSync.writeUTF("Resync:" + (i + 1));
                requestReSync.flush();
                DataInputStream readingData = new DataInputStream(s.getInputStream());
                String recoveredData = readingData.readUTF();
                if (!recoveredData.isEmpty()) {
                    String[] resultSplit = recoveredData.split(";");
                    for (String record : resultSplit) {
                        String[] rec = record.split("=");
                        if (!keyMap.containsKey(genHash(rec[0]))) {
                            keyMap.put(genHash(rec[0]), rec[0]);
                            dataMap.put(genHash(rec[0]), rec[1]);
                            dataMapTime.put(rec[1], String.valueOf(System.currentTimeMillis()));
                            privateMap.put(rec[0], rec[1]);
                        }
                    }
                    Log.i(TAG, "Data recovered");
                }
                s.close();
            }

            for (int i = 0; i < predPorts.size(); i++) {
                Socket s1 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(predPorts.get(i)));
                DataOutputStream requestReSync = new DataOutputStream(s1.getOutputStream());
                requestReSync.writeUTF("Private:" + (i + 1));
                requestReSync.flush();
                try {
                    DataInputStream readingData = new DataInputStream(s1.getInputStream());
                    String recoveredData = readingData.readUTF();
                    if (!recoveredData.isEmpty()) {
                        String[] resultSplit = recoveredData.split(";");
                        for (String record : resultSplit) {
                            String[] rec = record.split("=");
                            keyMap.put(genHash(rec[0]), rec[0]);
                            dataMap.put(genHash(rec[0]), rec[1]);
                            dataMapTime.put(rec[1], String.valueOf(System.currentTimeMillis()));
                            if (i == 0)
                                pred1Map.put(rec[0], rec[1]);
                            else
                                pred2Map.put(rec[0], rec[1]);
                        }
                        try {
                            Thread.sleep(100);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        Log.i(TAG, "Data recovered");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (NoSuchAlgorithmException e) {
            Log.e(TAG, "Hashing error");
        } catch (UnknownHostException e) {
            Log.e(TAG, "Error getting data");
        } catch (IOException e) {
            // If there is no response from any of the devices, I will catch the exception and continue requesting the remaining nodes.
            Log.e(TAG, "//////////////Devices not yet ready////////////////");
        }
    }


    //========================================================================================================================================================
    //========================================================================================================================================================

    private String genHash(String input) throws NoSuchAlgorithmException {
        MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
        byte[] sha1Hash = sha1.digest(input.getBytes());
        Formatter formatter = new Formatter();
        for (byte b : sha1Hash) {
            formatter.format("%02x", b);
        }
        return formatter.toString();
    }
}


//====================================================================================================================================================================
